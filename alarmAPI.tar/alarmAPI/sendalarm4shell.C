#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "alarm.h"

#define MAX_BUF_LEN 		198

#define DBMS                    "15"
#define ONINIT                  "36" 


int main (int argc, char *argv[])
{
    char    alarmcode[MAX_ALARMCODE_LEN+1];//��Ų��� alarmcode ��ֵ
    char    valve[MAX_VALVE_LEN+1];        //��Ų��� valve ��ֵ
    char    instance[MAX_INSTANCE_LEN+1];  //��Ų��� instance ��ֵ
    char    info[MAX_INFO_LEN+1];          //��Ų��� info ��ֵ
    int     i;
    char*   tmp_buf;
    char    path_buf[MAX_BUF_LEN+1];
    FILE*   fp1;

    TAlarm* pAlarm;
    
    tmp_buf = getenv("INFORMIXDIR");
    if (tmp_buf==NULL) 
    {
    	printf("Set $INFORMIXDIR first.\n");	
        exit (-1);   
    }
    if ( strlen (tmp_buf)>MAX_BUF_LEN-40) exit (-2);

    sprintf (path_buf, "%s/alarmAPI/sendalarm.log", tmp_buf);

    #ifdef _DEBUG_
    if ((fp1= fopen (path_buf, "a+"))==NULL) 
    {
        printf ("Failed to open sendalarm.log\n");
        exit (-3);
    } 
    fprintf (fp1, "sendalarm.log locates %s\n", path_buf);
    #endif

    sprintf (path_buf,"%s/alarmAPI/alarm.log", tmp_buf);
    
    #ifdef _DEBUG_
    fprintf (fp1, "alarm.log     locates %s\n", path_buf);
    #endif
    
    if ((pAlarm = new TAlarm( DBMS, ONINIT, argv[0], 0, path_buf))==NULL)
    {
        printf ("Memory allocation error! Exit.\n");
        
        #ifdef _DEBUG_ 
        fprintf (fp1, "Memory allocation error! Exit.\n");
        fprintf (fp1, "==== once end ====\n");
        fclose(fp1);
        #endif
        
        exit (-4);
    }
    
    sprintf (path_buf,"%s/alarmAPI/alarmcfg", tmp_buf);
    
    #ifdef _DEBUG_
    fprintf (fp1, "alarmcfg      locates %s\n", path_buf);
    #endif
    
    int errorCode = pAlarm->init(path_buf);
    if (errorCode != 0)
    {
    	printf("Init alarm error, ERROR CODE = %d!\n", errorCode);
    	  
    	#ifdef _DEBUG_ 
    	fprintf (fp1, "alarmcfg      locates %s\n", path_buf);
        fprintf (fp1, "Init alarm error, ERROR CODE = %d!\n", errorCode);
        fprintf (fp1, "==== once end ====\n");
        fclose(fp1);
        #endif
        
        delete pAlarm;  
        exit (-5);
    }

    if (argc != 5)
    {
        printf ("Usage:%s ALARMCODE VALVE INSTANCE INFO\n", argv[0]);
        printf ("Note :If any parameter is not necessary, please use NULL instead.\n");
        
        #ifdef _DEBUG_
        fprintf (fp1, "Usage:%s ALARMCODE VALVE INSTANCE INFO\n", argv[0]);
        fprintf (fp1, "==== once end ====\n");
        fclose (fp1);
        #endif
        
        delete pAlarm; 
        return -6;
    }

    if ( strlen (argv[1]) == MAX_ALARMCODE_LEN)
    {
        strcpy (alarmcode, argv[1]);
    }
    else
    {
        printf ("ALARMCODE length is wrong...\n");
        
	strncpy (alarmcode, argv[1], MAX_ALARMCODE_LEN);
	alarmcode[MAX_ALARMCODE_LEN]='\0';

        #ifdef _DEBUG_
        fprintf (fp1, "ALARMCODE length is wrong...\n");
        #endif
    }
    
    if ( strlen (argv[2])< MAX_VALVE_LEN)
    {
        if (( strcmp (argv[2], "NULL") ==0) || ( strcmp (argv[2], "null") ==0))
            strcpy (valve, "");
        else
            strcpy (valve, argv[2]);
    }
    else
    {
        printf ("Parameter VALVE is too long! Will be cut...\n");
	
	strncpy (valve, argv[2], MAX_VALVE_LEN);
	valve[MAX_VALVE_LEN]='\0';
        
        #ifdef _DEBUG_
        fprintf (fp1, "Parameter VALVE is too long! Will be cut...\n");
        #endif
    }

    if ( strlen (argv[3])< MAX_INSTANCE_LEN)
    {
        if (( strcmp (argv[3], "NULL") ==0) || ( strcmp (argv[3], "null") ==0))
            strcpy (instance, "");
        else
        {
            strcpy (instance, argv[3]);
            for(i=0; i< strlen (instance); i++)
	    {
                if(instance[i]=='"' || instance[i]=='\'' || instance[i]=='\n' || instance[i]=='\r')
                    instance[i]=' '; //���ɿո�
                if(i< strlen (instance)-1)
		    if(instance[i]=='-' && instance[i+1]=='-')
			instance[i]=' ';
            }
        }
    }
    else
    {
        printf("Parameter INSTANCE is too long! Will be cut...\n");
	
	strncpy (instance, argv[3], MAX_INSTANCE_LEN);
	instance[MAX_INSTANCE_LEN]='\0';
        
        #ifdef _DEBUG_
        fprintf (fp1, "Parameter INSTANCE is too long! Will be cut...\n");
        #endif
    }

    if ( strlen (argv[4])< MAX_INFO_LEN)
    {
        if (( strcmp (argv[4], "NULL") ==0) || ( strcmp (argv[4], "null") ==0))
            strcpy (info, "");
        else
        {
            strcpy (info, argv[4]);
            for (i=0; i< strlen (info); i++)
	    {
                if (info[i]=='"' || info[i]=='\'' || info[i]=='\n' || info[i]=='\r')
                    info[i]=' '; //���ɿո�            
                if (i< strlen (info)-1)
		    if (info[i]=='-' && info[i+1]=='-')
		        info[i]=' ';
	    }
        }
    }
    else
    {
        printf ("Parameter INFO is too long! Will be cut...\n");

        strncpy (info, argv[4], MAX_INFO_LEN);
	info[MAX_INFO_LEN]='\0';
        
        #ifdef _DEBUG_
        fprintf (fp1, "Parameter INFO is too long! Will be cut...\n");
        #endif
    }

    printf ("**** [%s] [%s] [%s] [%s] ****\n", alarmcode, valve, instance, info);
    int rv=pAlarm->sendalarm(alarmcode, valve, instance, info);
    printf ("******RV=%d\n",rv);
    
    #ifdef _DEBUG_
    fprintf (fp1, "alarmcode=[%s],valve=[%s],instance=[%s],info=[%s]\n",alarmcode,valve,instance,info);
    fprintf (fp1, "******RV=%d\n==== once end ====\n",rv);
    fclose (fp1);
    #endif
    
    delete pAlarm;
    return 1;
}
