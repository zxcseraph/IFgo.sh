/*
 *  Copyright(C) 2000 EASTCOM-BUPT Inc.
 *
 *  Filename            : $RCSfile: alarm.C,v $
 *  Last Revision       : $Revision: 1.1 $
 *  Last Revision Date  : $Date: 2005/11/21 13:17:56 $
 *  Description         :
 */
/** \file
  * \brief �澯�ӿ��ļ�
  *
  * �澯���ļ�
  */
#include <ctype.h>
#include "alarm.h"

 
///ʱ��ת������
char * TAlarm::timeSec2Str(time_t timeSec)
{
    struct tm *pTm;
    static char timeStr[30];
    
    if (timeSec == -1)
    {
        strcpy(timeStr, "NULL");
        return timeStr;
    }

    pTm = localtime(&timeSec);
    
    sprintf(timeStr, "%04d%02d%02d%02d%02d%02d", 
        pTm->tm_year + 1900,
        pTm->tm_mon + 1,
        pTm->tm_mday,
        pTm->tm_hour,
        pTm->tm_min,
        pTm->tm_sec);
	
    return timeStr;
}

///�����ַ�
#define isBlank(ch)	(ch==' '||ch=='\t'||ch=='\n'||ch=='\r')

///���ַ���ת����argv��ʽ����
int TAlarm::strToSet(char *str, char ***pSet, char sep)
{
    int argc;
    char prevCh;
    char *p;

    for (p=str,prevCh=sep,argc=0; *p; prevCh=*p++)
    {
    	if (!isBlank(*p) && prevCh == sep) argc++;
    }
    
    char *pBuffer = new char[sizeof(char*)*(argc) + strlen(str)+1];
    char **argv = (char**) pBuffer;
    char *argStr = pBuffer + sizeof(char*)*(argc);
	
    strcpy(argStr, str);
    
    for (p=argStr,prevCh=0,argc=0; *p; prevCh=*p++)
    {
        if (*p == sep || *p == '\n') *p = 0;
        if (*p && !prevCh) argv[argc++] = p;
    }
    
    *pSet = argv;
    return argc;
}

///���͸澯����
int TAlarm::m_send(char* pmsgbuf)
{
	int					sockfd_client;
	struct sockaddr_in	locaddr;
	struct sockaddr_in	destaddr;
	time_t				cur_time;
	int					i;
	int					n;
	int len=strlen(pmsgbuf);//20050518
	
	sockfd_client = socket(AF_INET,SOCK_DGRAM, 0);
	
	if (sockfd_client<0) return -1;
	
	locaddr.sin_family = AF_INET;
	locaddr.sin_port = htons(0);
	locaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(locaddr.sin_zero, 8);
	for (i = 0; i < m_svrNum; i++)
	{
		if ((m_svrPort[i] == -1) || (strcmp(m_svrAddr[i], "0.0.0.0") == 0)) continue;
		
		destaddr.sin_family = AF_INET;
		destaddr.sin_port = htons(m_svrPort[i]);
		destaddr.sin_addr.s_addr = inet_addr(m_svrAddr[i]);
		bzero(destaddr.sin_zero, 8);

		sendto(sockfd_client,
				pmsgbuf,       //! pmsgbuf --->(char *)pmsgbuf
				len,
				0,
				(struct sockaddr *)&destaddr,
				sizeof(struct sockaddr));//20050518
	}
	
	close(sockfd_client);
	return 0;
}

///��ȡ�澯������Ϣ����
/**
  *return  0: SUCCESS
  *return -1: read config file error;
  *return -2: get config content error;
  *return -3: too many SERVER;
  *return -4: not found SERVER.
  */
int TAlarm::m_chgcfg(void)
{
	int i;
	char **ServerInfo = NULL;
	int InfoNum;
	char buf[200];
	int buflen;
	char *ps;
	FILE *fp = NULL;
	
	for (i = 0; i < MAX_SERVER_NUM; i++)
	{
		m_svrPort[i] = -1;
		strcpy(m_svrAddr[i], "0.0.0.0");
	}
	
	// Read alarm config
	if (NULL == (fp=fopen(m_cfgPath,"r"))) return -1;
	
	m_svrNum = 0;
	
	while(1)
	{
		fgets(buf,100,fp);
		if(feof(fp)) return -2;
		
		buflen = strlen(buf);
		int j;
		for(j=0;j<buflen;j++)
		{
			if(buf[j]==10||buf[j]==13)
			{
				buf[j]='\0';
				break;
			}
		}
		
		
		if (!strcmp(buf,"END")) break;
		
		for (i = 0; i < buflen; i++)
		{
			if (buf[i] == '=') break;
		}
		
		if (i >= buflen) continue;
		
		ps = buf+i+1;
		buf[i] = '\0';
		
		if (!strcmp(buf,"SERVER"))
		{
			InfoNum = strToSet(ps, &ServerInfo, ':');
			
			if (2 == InfoNum)
			{
				strncpy(m_svrAddr[m_svrNum], ServerInfo[0], MAX_ADDR_LEN);
				m_svrAddr[m_svrNum][MAX_ADDR_LEN] = '\0';
				m_svrPort[m_svrNum] = atol(ServerInfo[1]);
				m_svrNum++;
			}
			
			if (m_svrNum > MAX_SERVER_NUM)
			{
				fclose(fp);
				delete ServerInfo;
				ServerInfo = NULL;
				return -3;
			}
		}
	}
	
	fclose(fp);
	delete ServerInfo;
	ServerInfo = NULL;
	
	if (m_svrNum < 1) return -4;
	
	return 0;
}

///д��־����
void TAlarm::m_log(char *buf)
{
	FILE	*fp;
	time_t	cur_time;
	struct tm	*pTm = NULL;
	char	wDay[10];
	
	if (strlen(m_logPath) == 0) return;
	if ((fp = fopen(m_logPath, "at")) == NULL) return;
	
	time(&cur_time);
	pTm = localtime(&cur_time);
	switch (pTm->tm_wday)
	{
		case 0: strcpy(wDay, "Sunday"); break;
		case 1: strcpy(wDay, "Monday");	break;
		case 2: strcpy(wDay, "Tuesday"); break;
		case 3: strcpy(wDay, "Wednesday"); break;
		case 4: strcpy(wDay, "Thursday"); break;
		case 5: strcpy(wDay, "Friday"); break;
		case 6: strcpy(wDay, "Saturday"); break;
	}
	fprintf(fp,
			 "%04d/%02d/%02d  %s  %02d:%02d:%02d    %s\n",
			 pTm->tm_year + 1900,
			 pTm->tm_mon + 1,
			 pTm->tm_mday,
			 wDay,
			 pTm->tm_hour,
			 pTm->tm_min,
			 pTm->tm_sec,
			 buf);
			
	fclose(fp);
}

///���캯��
TAlarm::TAlarm(const char *dev, const char *mod, const char* modname, unsigned char id)
{
	m_Dev[0] = 0;
	m_Mod[0] = 0;
	m_Modname[0] = 0;
	m_Modid[0]=0;
	
	if ((NULL == dev) || (NULL == mod))
	{
		m_initFinished = -1;
	}
	else if ((2 != strlen(dev)) || (2 != strlen(mod)) || (strlen(modname)>MAX_MODULENAME_LEN))
	{
		m_initFinished = -2;
	}
	else
	{
		strcpy(m_Dev, dev);
		strcpy(m_Mod, mod);
		strcpy(m_Modname,modname);
		m_Modid[0]=id;
		m_initFinished = 0;
	}

	strcpy( m_logPath, "" );
	m_logFlag = 0;
	
	//<songlei
	m_lastSendTime=0;//++songlei
	//m_lastalarmcode = NULL;
	//m_lastspecific = NULL;
	//m_lastreserved = NULL;
	//songlei>
}

///���캯��
TAlarm::TAlarm(const char *dev, const char *mod, const char* modname, unsigned char id, const char *alarmlogPath)
{
	m_Dev[0] = 0;
	m_Mod[0] = 0;
	m_Modname[0] = 0;
	m_Modid[0]=0;
	
	if ((NULL == dev) || (NULL == mod) ||(NULL == alarmlogPath))
	{
		m_initFinished = -1;
	}
	else if ((2 != strlen(dev)) || (2 != strlen(mod)) || (strlen(modname)>MAX_MODULENAME_LEN) || (199 < strlen(alarmlogPath)))
	{
		m_initFinished = -2;
	}
	else
	{
		strcpy(m_Dev, dev);
		strcpy(m_Mod, mod);
		strcpy(m_Modname,modname);
		m_Modid[0]=id;
		m_initFinished = 0;
	}
    
	strncpy(m_logPath, alarmlogPath, 199);
	m_logPath[199] = '\0';
	
	m_logFlag = 1;
	
	//<songlei
	m_lastSendTime=0;//++songlei
	//m_lastalarmcode = NULL;
	//m_lastspecific = NULL;
	//m_lastreserved = NULL;
	//songlei>
}

///��������
TAlarm::~TAlarm()
{
}

///��ʼ������
/**
  * Input arguments of the following functions:
  *		alarmcfgpath:	alarmclient config path.
  * Return value of the following functions:
  *		 0:	SUCCESS;
  *		-1: TALARM: argument can not be null;
  *		-2: TALARM: argument length error;
  *		-3: INIT: argument can not be null;
  *		-4: INIT: argument length error;
  *		-5: INIT: read config file failed or set configuration format error;
  *		-6: INIT: create Log file error;
  *		-7: INIT: get Login name error;
  *		-8: INIT: get Host name error;
  *		-9: INIT: get Cluster error;
  *	   -10: INIT: get pid error;
  *	  -100: INIT: send message failed.
  */
int TAlarm::init(const char *alarmcfgpath)
{
	FILE *fp = NULL;
	struct AlarmMesg msgbuf;
	struct hostent *h;
	time_t cur_time;
	char *pcurrenttime = NULL;
	char *mCluster = NULL;
	struct passwd *myName = NULL;
	pid_t mPid;
	char tempBuf[1000];
	
	if (0 != m_initFinished) return m_initFinished;
	if (NULL == alarmcfgpath) return -3;
	if (199 < strlen(alarmcfgpath)) return -4;
	
	strncpy(m_cfgPath, alarmcfgpath, 199);
	m_cfgPath[199] = '\0';
	
	if (0 != m_chgcfg()) return -5;
	
	if (1 == m_logFlag)
	{
		if ((fp = fopen(m_logPath, "at")) == NULL)
			return -6;
		else
			fclose(fp);
	}
	
    myName = getpwuid(geteuid());
    if (NULL == myName) return -7;
    strcpy(m_logName, myName->pw_name);
    m_logName[MAX_LOGNAME_LEN]='\0';
    
    if (0 != gethostname(m_Host, MAX_HOSTNAME_LEN)) return -8;
	m_Host[MAX_HOSTNAME_LEN]='\0';
	
	if (NULL == (mCluster = getenv("CLUSTER"))) return -9;
	strncpy(m_Cluster, mCluster, MAX_CLUSTER_LEN);
	m_Cluster[MAX_CLUSTER_LEN]='\0';
	
	if (-1 == (mPid = getpid())) return -10;
	sprintf(m_Pid, "%d", mPid);
	m_Pid[MAX_PID_LEN]='\0';

	msgbuf.mesg_type[0] = ALARM_INIT_MESG;
	msgbuf.mesg_type[MAX_ALARMMESGTYPE_LEN] = '\0';
	strcpy(msgbuf.host, m_Host);
	strcpy(msgbuf.logname, m_logName);
	strcpy(msgbuf.cluster, m_Cluster);
	strcpy(msgbuf.pid, m_Pid);
	strcpy(msgbuf.modulename, m_Modname);
	msgbuf.moduleid[0]= m_Modid[0];
	msgbuf.moduleid[1]=0;
	time(&cur_time);
    pcurrenttime = timeSec2Str(cur_time);
    strncpy(msgbuf.warntime, pcurrenttime, MAX_TIME_LEN);
    msgbuf.warntime[MAX_TIME_LEN]='\0';
	h = gethostbyname(msgbuf.host);
	if (NULL != h){
		strcpy(msgbuf.info, inet_ntoa(*(struct in_addr *)h->h_addr));
               msgbuf.info[MAX_INFO_LEN]='\0';	
}else
		msgbuf.info[0]='\0';
		msgbuf.reserved[0]='\0';
	//20050518
	char codebuf[MAX_MESG_STRING_LEN];
	for(int i=0;i<MAX_MESG_STRING_LEN;i++)
	codebuf[i]='\0';
	code(&msgbuf,codebuf,MAX_MESG_STRING_LEN);
	
	if (m_send(codebuf) < 0) return -100;
	
	if (1 == m_logFlag)
	{	
		strcpy(tempBuf, "INIT: SUCCESSED.");
		m_log(tempBuf);
	}

	m_initFinished = 1;
	
	m_lastSendTime = time(NULL);//++songlei
	m_lastalarmcode[0] ='\0' ;
	m_lastspecific[0] = '\0';
	m_lastreserved[0] = '\0';
	
	
	return 0;
}
//����tagֵ���ظ���ʵ��ֵ����
int TAlarm::AlarmMsg_tag_Value_length(int tag,struct AlarmMesg *alarm_msg)
{
	int AlarmMsg_tag_length=0;
	switch(tag)
	{
	 case 1: AlarmMsg_tag_length=strlen(alarm_msg->mesg_type);
	         break;
	 case 2: AlarmMsg_tag_length=strlen(alarm_msg->alarmcode);
	         break;
	 case 3: AlarmMsg_tag_length=strlen(alarm_msg->dev);
	         break;
	 case 4: AlarmMsg_tag_length=strlen(alarm_msg->mod);
	         break;
	 case 5: AlarmMsg_tag_length=strlen(alarm_msg->alarmtype);
	         break;
	 case 6: AlarmMsg_tag_length=strlen(alarm_msg->valve);
	         break; 
	 case 7: AlarmMsg_tag_length=strlen(alarm_msg->instance);
	         break;
	 case 8: AlarmMsg_tag_length=strlen(alarm_msg->info);
	         break;
	 case 9: AlarmMsg_tag_length=strlen(alarm_msg->host);
	         break;                                                               
	 case 10: AlarmMsg_tag_length=strlen(alarm_msg->logname);
	         break;
	 case 11: AlarmMsg_tag_length=strlen(alarm_msg->cluster);
	         break;
	case 12: AlarmMsg_tag_length=strlen(alarm_msg->modulename);
	         break;
	case 13: AlarmMsg_tag_length=strlen(alarm_msg->moduleid);
	         break;
	case 14: AlarmMsg_tag_length=strlen(alarm_msg->pid);
	         break;
	case 15: AlarmMsg_tag_length=strlen(alarm_msg->warntime);
	         break;
	case 16: AlarmMsg_tag_length=strlen(alarm_msg->reserved);
	         break; 
	default: AlarmMsg_tag_length=-1;                                           	
	}
	return AlarmMsg_tag_length;
}
//����tagֵ���ظ����
int TAlarm::AlarmMsg_tag_Key_length(int tag)
{
	int AlarmMsg_tag_length=0;
	char buf[1024];
	switch(tag)
	{
	 case 1: sprintf(buf,"mesg_type");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 2: sprintf(buf,"alarmcode");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 3: sprintf(buf,"dev");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 4: sprintf(buf,"mod");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 5: sprintf(buf,"alarmtype");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 6: sprintf(buf,"valve");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break; 
	 case 7: sprintf(buf,"instance");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 8: sprintf(buf,"info");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	 case 9: sprintf(buf,"host");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	                                                        
	 case 10:sprintf(buf,"logname");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;        
	 case 11:sprintf(buf,"cluster");
	 	 AlarmMsg_tag_length=strlen(buf);
	         break;
	case 12:sprintf(buf,"modulename");
		 AlarmMsg_tag_length=strlen(buf);
	         break;
	case 13: sprintf(buf,"moduleid");
		 AlarmMsg_tag_length=strlen(buf);
	         break;
	case 14: sprintf(buf,"pid");
		 AlarmMsg_tag_length=strlen(buf);
	         break;
	case 15: sprintf(buf,"warntime");
		 AlarmMsg_tag_length=strlen(buf);
	         break;
	case 16: sprintf(buf,"reserved");
		 AlarmMsg_tag_length=strlen(buf);
	         break; 
	default: AlarmMsg_tag_length=-1;                                           	
	}
	return AlarmMsg_tag_length;
}
//����tagֵ���ظ���ֵ
void TAlarm::AlarmMsg_tag_Key(int tag,char *buf)
{
	
	
	switch(tag)
	{
	 case 1: sprintf(buf,"mesg_type");
	 	 break;
	        
	 case 2: sprintf(buf,"alarmcode");
	 	 break;
	 case 3: sprintf(buf,"dev");
	 	 break;
	 case 4: sprintf(buf,"mod");
	 	 break;
	 case 5: sprintf(buf,"alarmtype");
	 	 break;
	 case 6: sprintf(buf,"valve");
	 	  break;
	 case 7: sprintf(buf,"instance");
	 	break;
	 case 8: sprintf(buf,"info");
	 	 break;
	 case 9: sprintf(buf,"host");
	 	 break;
	                                                         
	 case 10:sprintf(buf,"logname");
	 	   break;    
	 case 11:sprintf(buf,"cluster");
	 	 break;
	case 12:sprintf(buf,"modulename");
		 break;
	case 13: sprintf(buf,"moduleid");
		 break;
	case 14: sprintf(buf,"pid");
		 break;
	case 15: sprintf(buf,"warntime");
		 break;
	case 16: sprintf(buf,"reserved");
		 break;
	default: buf[0]='\0';                                         	
	}
	
}
//����tagֵ���ظ���ʵ��ֵ
char* TAlarm::AlarmMsg_tag_value(int tag,struct AlarmMesg *alarm_msg)
{
	switch(tag)
	{
	 case 1: return alarm_msg->mesg_type;
	        
	 case 2: return alarm_msg->alarmcode;
	         
	 case 3: return alarm_msg->dev;
	         
	 case 4: return alarm_msg->mod;
	         
	 case 5: return alarm_msg->alarmtype;
	         
	 case 6: return alarm_msg->valve;
	          
	 case 7: return alarm_msg->instance;
	         
	 case 8: return alarm_msg->info;
	         
	 case 9: return alarm_msg->host;
	                                                                        
	 case 10:return alarm_msg->logname;
	         
	 case 11:return alarm_msg->cluster;
	         
	case 12: return alarm_msg->modulename;
	         
	case 13: return alarm_msg->moduleid;
	         
	case 14: return alarm_msg->pid;
	         
	case 15: return alarm_msg->warntime;
	         
	case 16: return alarm_msg->reserved;
	          
	default: return NULL;
    }	
}
//�澯����20050518
void TAlarm::code(struct AlarmMesg *alarm_msg,char *codebuf,int bufsize)
{
	int totallength=0;
	int bufpos=0;
	//int bufsize=sizeof(codebuf);
	int keylength=0;
	int valuelength=0;
	int msglength=0;
	char *tempbuf=new char[bufsize];
	char msg_length[10];
	char keybuf[1024];
	char logbuf[1000];
	for(int i=1;i<=16&&totallength<bufsize;i++)
	{
		keylength=AlarmMsg_tag_Key_length(i);
		msglength=AlarmMsg_tag_Value_length(i,alarm_msg);
		sprintf(msg_length,"%d",msglength);
		valuelength=strlen(msg_length);
		//printf("msglength:%d\n",msglength);
		if(msglength>=0) //���ǿ���Ϣ
		{
		
		if(totallength+msglength+keylength+valuelength+3<bufsize)
		{
			if(AlarmMsg_tag_value(i,alarm_msg))
		{ 
		   AlarmMsg_tag_Key(i,keybuf);
		   if(strlen(keybuf)>0)
		   {
		   sprintf(&tempbuf[bufpos],"[%s,%s]",keybuf,msg_length);
		   bufpos+=keylength+valuelength+3;
		  strncpy(&tempbuf[bufpos],AlarmMsg_tag_value(i,alarm_msg),msglength);
		  bufpos+=msglength;
		  //printf("codebuf:%s,%d\n",&codebuf[bufpos],bufpos);
		  totallength+=msglength+keylength+valuelength+3;
		}
		else
		{
			//log not existkey
		sprintf(logbuf, "alarmmessage has wrong key!");
		 m_log(logbuf);
			
		}
		}
		else
		{
		   //log null
		 sprintf(logbuf, "alarmmessage has null value!");
		 m_log(logbuf);
		   
		   
		}
		}
		else
		{
		  //log length too long
		sprintf(logbuf, "alarmmessage has too long length!");
		 m_log(logbuf);
		  
		  break;
		}
		}//if ���ǿ���Ϣ
		else
		{
		 //log length wrong
		 sprintf(logbuf, "alarmmessage has wrong length!");
		 m_log(logbuf);
		 
		}
		
	}//for
	tempbuf[totallength]='\0';
	sprintf(codebuf,"%d%s",totallength,tempbuf);
	
	//printf("\n");
	//printf(" before send:%s,%d\n",codebuf,strlen(codebuf));
	
}
///���͸澯����
/**
  * Input arguments of the following functions:
  *		alarmcode:	alarm message code;
  *		valve:		alarm valve;
  *		specific:	alarm specific information;
  *		info:		alarm comment;
  *		reserved:	reserved.
  * Return value of the following functions:
  *		 0:	SUCCESS;
  *		-1: SENDALARM: run init() first;
  *		-2: SENDALARM: argument can not be null;
  *		-3: SENDALARM: argument length error;
  *		-4: SENDALARM: argument format error;
  *	  -100: SENDALARM: send message failed.
  */
int TAlarm::sendalarm(const char *alarmcode,
						const char *valve,
						const char *specific,
						const char *info,
						const char *reserved)
{
	struct	AlarmMesg	msgbuf;
	char	tempBuf[1000];
	time_t	cur_time;
	char 	*pcurrenttime = NULL;
	int		i;

	if (1 != m_initFinished)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SENDALARM: run init() first.");
			m_log(tempBuf);
		}
		return -1;
	}
	if ((NULL == alarmcode)
		|| (NULL == valve)
		|| (NULL == specific)
		|| (NULL == info)
		|| (NULL == reserved))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SENDALARM: argument can not be null.");
			m_log(tempBuf);
		}
		return -2;
	}
	if ((MAX_ALARMCODE_LEN != strlen(alarmcode))//�澯����11λ20050620
		|| (MAX_VALVE_LEN < strlen(valve))
		|| (MAX_INSTANCE_LEN < strlen(specific))
		|| (MAX_INFO_LEN < strlen(info))
		|| (MAX_RESERVED_LEN < strlen(reserved)))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SENDALARM: argument length error.");
			m_log(tempBuf);
		}
		return -3;
	}
	
	//++ songlei
	int i0 = strcmp(m_lastalarmcode,alarmcode);	
	int i1 = strcmp(m_lastspecific,specific);
	int i2 = strcmp(m_lastreserved,reserved); 
	if((i0==0)&&(i1==0)&&(i2==0))
	{
		//��������Ҫ������ƥ��
		time_t nowtime = time(NULL);
		if(nowtime - m_lastSendTime < CONST_ALARM_INTERVAL)
		{
			sprintf(tempBuf, "ALARM has been filtered: Alarmcode[%s],Instance[%s],reserved[%s]", alarmcode,specific, reserved );
			m_log(tempBuf);
			return 0;
		}
	}
	
	// Fill the datagram---alarm message.
	msgbuf.mesg_type[0] = ALARM_SEND_TYPE;
	msgbuf.mesg_type[MAX_ALARMMESGTYPE_LEN] = '\0';
	
	strncpy(msgbuf.alarmcode, alarmcode, MAX_ALARMCODE_LEN);
	msgbuf.alarmcode[MAX_ALARMCODE_LEN]='\0';
	
	strncpy(msgbuf.dev, m_Dev, MAX_DEVICE_LEN);
	msgbuf.dev[MAX_DEVICE_LEN]='\0';
	
	strncpy(msgbuf.mod, m_Mod, MAX_MODULE_LEN);
	msgbuf.mod[MAX_MODULE_LEN]='\0';
	
	alarmcode += 4;
	strncpy(msgbuf.alarmtype, alarmcode, MAX_ALARMTYPE_LEN);
	msgbuf.alarmtype[MAX_ALARMTYPE_LEN]='\0';
	
	strncpy(msgbuf.valve, valve, MAX_VALVE_LEN);
	msgbuf.valve[MAX_VALVE_LEN]='\0';
	
	strncpy(msgbuf.instance, specific, MAX_INSTANCE_LEN);
	msgbuf.instance[MAX_INSTANCE_LEN]='\0';
	
	strncpy(msgbuf.info, info, MAX_INFO_LEN);
	msgbuf.info[MAX_INFO_LEN]='\0';
	
	strcpy(msgbuf.host, m_Host);
	strcpy(msgbuf.logname, m_logName);
	strcpy(msgbuf.cluster, m_Cluster);
	strcpy(msgbuf.pid, m_Pid);
	strcpy(msgbuf.modulename, m_Modname);
	msgbuf.moduleid[0]= m_Modid[0];
	msgbuf.moduleid[1]=0;
	time(&cur_time);
	pcurrenttime = timeSec2Str(cur_time);
	strncpy(msgbuf.warntime, pcurrenttime, MAX_TIME_LEN);
	msgbuf.warntime[MAX_TIME_LEN]='\0';
	strncpy(msgbuf.reserved, reserved, MAX_RESERVED_LEN);
	msgbuf.reserved[MAX_RESERVED_LEN]='\0';
	
	// Chect valve right if it is digit.
	if (('4' == msgbuf.alarmtype[0]) && ('1' == msgbuf.alarmtype[1]))
	{
		if (0 == strlen(valve))
		{
			if (1 == m_logFlag)
			{
				sprintf(tempBuf, "SENDALARM: argument format error.");
				m_log(tempBuf);
			}
			return -4;
		}
		for (i = 0; i < strlen(valve); i++)
		{
			if (!isdigit(valve[i]))
			{
				if (1 == m_logFlag)
				{
					sprintf(tempBuf, "SENDALARM: argument format error.");
					m_log(tempBuf);
				}
				return -4;
			}
		}
	}
	//20050518����
	char codebuf[MAX_MESG_STRING_LEN];
	//int i;
	for(i=0;i<MAX_MESG_STRING_LEN;i++)
	codebuf[i]='\0';
	code(&msgbuf,codebuf,MAX_MESG_STRING_LEN);
	printf("send:%s\n",codebuf);
	//20050518
	// send alarm message to all servers
	if (m_send(codebuf) < 0)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SENDALARM: send message failed.");
			m_log(tempBuf);
		}
		return -100;
	}
	
	if (1 == m_logFlag)
	{
		sprintf(tempBuf, "SENDALARM: Alarmcode[%s],Valve[%s],Instance[%s],Info[%s]", msgbuf.alarmcode, msgbuf.valve, msgbuf.instance, msgbuf.info);
		m_log(tempBuf);
	}
	//<songlei
	m_lastSendTime = time(NULL);
	strcpy(m_lastalarmcode,msgbuf.alarmcode);
	m_lastalarmcode[MAX_ALARMCODE_LEN]= '\0';
	strcpy(m_lastspecific,specific);
	m_lastspecific[MAX_INSTANCE_LEN] = '\0';
	strcpy(m_lastreserved,reserved);
	m_lastreserved[MAX_RESERVED_LEN] = '\0';
	//songlei>

	return 0;
}

///���ø澯����
/**
  * Input arguments of the following functions:
  *		alarmcode:	alarm message code;
  *		valve:		alarm valve;
  *		reserved:	reserved.
  * Return value of the following functions:
  *		 0:	SUCCESS;
  *		-1: SETALARM: run init() first;
  *		-2: SETALARM: argument can not be null;
  *		-3: SETALARM: argument length error;
  *		-4: SETALARM: argument format error;
  *	  -100: SETALARM: send message failed.
  */
int TAlarm::setalarm(const char *alarmcode,
						const char *valve,
						const char *reserved)
{
	struct AlarmMesg	msgbuf;
	char	tempBuf[1000];
	time_t	cur_time;
	char 	*pcurrenttime = NULL;
int i;
	if (1 != m_initFinished)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SETALARM: run init() first.");
			m_log(tempBuf);
		}
		return -1;
	}
	if ((NULL == alarmcode) || (NULL == valve) || (NULL == reserved))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SETALARM: argument can not be null.");
			m_log(tempBuf);
		}
		return -2;
	}
	if ((MAX_ALARMCODE_LEN != strlen(alarmcode))//�澯����11λ20050620
		|| (MAX_VALVE_LEN < strlen(valve))
		|| (MAX_RESERVED_LEN < strlen(reserved)))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SETALARM: argument length error.");
			m_log(tempBuf);
		}
		return -3;
	}
	
	// Chect valve right if it is digit.
	if (0 == strlen(valve))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SETALARM: argument format error.");
			m_log(tempBuf);
		}
		return -4;
	}
	for ( i= 0; i < strlen(valve); i++)
	{
		if (!isdigit(valve[i]))
		{
			if (1 == m_logFlag)
			{
				sprintf(tempBuf, "SETALARM: argument format error.");
				m_log(tempBuf);
			}
			return -4;
		}
	}
	
	// Fill the datagram---alarm message.
	msgbuf.mesg_type[0] = ALARM_SET_TYPE;
	msgbuf.mesg_type[MAX_ALARMMESGTYPE_LEN] = '\0';
	strncpy(msgbuf.alarmcode, alarmcode, MAX_ALARMCODE_LEN);
	msgbuf.alarmcode[MAX_ALARMCODE_LEN]='\0';
	strncpy(msgbuf.dev, m_Dev, MAX_DEVICE_LEN);
	msgbuf.dev[MAX_DEVICE_LEN]='\0';
	strncpy(msgbuf.mod, m_Mod, MAX_MODULE_LEN);
	msgbuf.mod[MAX_MODULE_LEN]='\0';
	alarmcode += 4;
	strncpy(msgbuf.alarmtype, alarmcode, MAX_ALARMTYPE_LEN);
	msgbuf.alarmtype[MAX_ALARMTYPE_LEN]='\0';
	strncpy(msgbuf.valve, valve, MAX_VALVE_LEN);
	msgbuf.valve[MAX_VALVE_LEN]='\0';
	msgbuf.instance[0]='\0';
	msgbuf.info[0]='\0';
	strcpy(msgbuf.host, m_Host);
	strcpy(msgbuf.logname, m_logName);
	strcpy(msgbuf.cluster, m_Cluster);
	strcpy(msgbuf.pid, m_Pid);
	strcpy(msgbuf.modulename, m_Modname);
	time(&cur_time);
	pcurrenttime = timeSec2Str(cur_time);
	strncpy(msgbuf.warntime, pcurrenttime, MAX_TIME_LEN);
	msgbuf.warntime[MAX_TIME_LEN]='\0';
	strncpy(msgbuf.reserved, reserved, MAX_RESERVED_LEN);
	msgbuf.reserved[MAX_RESERVED_LEN]='\0';
	//20050518
	char codebuf[MAX_MESG_STRING_LEN];
	//int i;
	for(i=0;i<MAX_MESG_STRING_LEN;i++)
	codebuf[i]='\0';
	code(&msgbuf,codebuf,MAX_MESG_STRING_LEN);
	// send alarm message to all servers
	if (m_send(codebuf) < 0)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "SETALARM: send message failed.");
			m_log(tempBuf);
		}
		return -100;
	}

	if (1 == m_logFlag)
	{
		sprintf(tempBuf, "SETALARM: Alarmcode[%s],Valve[%s]", msgbuf.alarmcode, msgbuf.valve);
		m_log(tempBuf);
	}

	return 0;
}

///����澯����
/**
  * Input arguments of the following functions:
  *		alarmcode:	alarm message code;
  *		specific:	alarm specific information;
  *		reserved:	reserved.
  * Return value of the following functions:
  *		 0:	SUCCESS;
  *		-1: CLRALARM: run init() first;
  *		-2: CLRALARM: argument can not be null;
  *		-3: CLRALARM: argument length error;
  *	  -100: CLRALARM: send message failed.
  */
int TAlarm::clralarm(const char *alarmcode,
						const char *specific,
						const char *reserved)
{
	struct AlarmMesg	msgbuf;
	char	tempBuf[1000];
	time_t	cur_time;
	char 	*pcurrenttime = NULL;

	if (1 != m_initFinished)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CLRALARM: run init() first.");
			m_log(tempBuf);
		}
		return -1;
	}
	if ((NULL == alarmcode)
		|| (NULL == specific)
		|| (NULL == reserved))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CLRALARM: argument can not be null.");
			m_log(tempBuf);
		}
		return -2;
	}
	if ((MAX_ALARMCODE_LEN != strlen(alarmcode))//�澯����11λ20050620
		|| (MAX_INSTANCE_LEN < strlen(specific))
		|| (MAX_RESERVED_LEN < strlen(reserved)))
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CLRALARM: argument length error.");
			m_log(tempBuf);
		}
		return -3;
	}
	
	
	// fill the data gram----alarm message
	msgbuf.mesg_type[0] = ALARM_CLEAR_TYPE;
	msgbuf.mesg_type[MAX_ALARMMESGTYPE_LEN] = '\0';
	strncpy(msgbuf.alarmcode, alarmcode, MAX_ALARMCODE_LEN);
	msgbuf.alarmcode[MAX_ALARMCODE_LEN]='\0';
	strncpy(msgbuf.dev, m_Dev, MAX_DEVICE_LEN);
	msgbuf.dev[MAX_DEVICE_LEN]='\0';
	strncpy(msgbuf.mod, m_Mod, MAX_MODULE_LEN);
	msgbuf.mod[MAX_MODULE_LEN]='\0';
	alarmcode += 4;
	strncpy(msgbuf.alarmtype, alarmcode, MAX_ALARMTYPE_LEN);
	msgbuf.alarmtype[MAX_ALARMTYPE_LEN]='\0';
	msgbuf.valve[0]='\0';
	strncpy(msgbuf.instance, specific, MAX_INSTANCE_LEN);
	msgbuf.instance[MAX_INSTANCE_LEN]='\0';
	msgbuf.info[0]='\0';
	strcpy(msgbuf.host, m_Host);
	strcpy(msgbuf.logname, m_logName);
	strcpy(msgbuf.cluster, m_Cluster);
	strcpy(msgbuf.pid, m_Pid);
	strcpy(msgbuf.modulename, m_Modname);
	msgbuf.moduleid[0]= m_Modid[0];
	msgbuf.moduleid[1]=0;
	time(&cur_time);
    pcurrenttime = timeSec2Str(cur_time);
    strncpy(msgbuf.warntime, pcurrenttime, MAX_TIME_LEN);
    msgbuf.warntime[MAX_TIME_LEN]='\0';
    strncpy(msgbuf.reserved, reserved, MAX_RESERVED_LEN);
	msgbuf.reserved[MAX_RESERVED_LEN]='\0';
	//20050518
	char codebuf[MAX_MESG_STRING_LEN];
	for(int i=0;i<MAX_MESG_STRING_LEN;i++)
	codebuf[i]='\0';
	code(&msgbuf,codebuf,MAX_MESG_STRING_LEN);
	// send alarm message to all servers
	if (m_send(codebuf) < 0)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CLRALARM: send message failed.");
			m_log(tempBuf);
		}
		return -100;
	}
	if (1 == m_logFlag)
	{
		sprintf(tempBuf, "CLRALARM: Alarmcode[%s],Instance[%s]", msgbuf.alarmcode, msgbuf.instance);
		m_log(tempBuf);
	}
	
	return 0;
}

///��ȡ�澯���ú���
/**
  * Input arguments of the following functions:
  *		null.
  * Return value of the following functions:
  *		 0:	SUCCESS;
  *		-1: CHGCONFIG: run init() first;
  *		-2: CHGCONFIG: read config file failed or set configuration format error;
  */
int TAlarm::chgconfig(void)
{
	char tempBuf[1000];
	
	if (1 != m_initFinished)
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CHGCONFIG: Run init() first.");
			m_log(tempBuf);
		}
		return -1;
	}
	
	if (0 != m_chgcfg())
	{
		if (1 == m_logFlag)
		{
			sprintf(tempBuf, "CHGCONFIG: read config file failed or set configuration format error.");
			m_log(tempBuf);
		}
		return -2;
	}
	
	if (1 == m_logFlag)
	{
		sprintf(tempBuf, "CHGCONFIG: SUCCESS");
		m_log(tempBuf);
	}
	
	return 0;
}
